package com.example.rfidapp;

public class LoginResult {
    private String name;

    private String email;
    private  String pass;

    public String getName()
    {
        return name;
    }

    public String getEmail()
    {
        return email;
    }
    public String getPass()
    {
        return pass;
    }
}
