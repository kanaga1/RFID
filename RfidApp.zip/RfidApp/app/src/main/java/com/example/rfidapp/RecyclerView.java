package com.example.rfidapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rfidapp.Retrofit.RetrofitInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RecyclerView extends AppCompatActivity {
    private Retrofit retrofit;
    TextView textView;
    private String BASE_URL = "http://192.168.0.102:3000/";
    private RetrofitInterface retrofitInterface;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        textView = (TextView)findViewById(R.id.text_view_result);
        retrofitInterface = retrofit.create(RetrofitInterface.class);

        Call<GetData> call = retrofitInterface.doGetListResources();

        call.enqueue(new Callback<GetData>() {
            @Override
            public void onResponse(Call<GetData> call, Response<GetData> response) {

                if (response.code() == 200) {
                     GetData list;
                     String result="";
                    list = response.body();
                    JSONObject jsonObject = null;
                    try {
                        jsonObject = new JSONObject(String.valueOf(list));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    // Getting JSON Array node
                    JSONArray contacts = null;
                    try {
                        contacts = jsonObject.getJSONArray("data");
                        // looping through All Contacts
                        for (int i = 0; i < contacts.length(); i++) {
                            JSONObject c = contacts.getJSONObject(i);
                            String name = c.getString("name");
                            String email = c.getString("email");
                            String password = c.getString("password");


                            result += "Name: " + name +"\n" + "Email: " + email + "\n" + "Password" + password + "\n";

                            textView.setText(result);
                        }

                    }

                    catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                }
            @Override
            public void onFailure(Call<GetData> call, Throwable t) {
                Toast.makeText(RecyclerView.this, t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
