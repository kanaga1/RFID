package com.example.rfidapp.Retrofit;

import com.example.rfidapp.GetData;
import com.example.rfidapp.LoginResult;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RetrofitInterface {

    @POST("/login")
    Call<LoginResult> executeLogin(@Body HashMap<String, String> map);

    @GET("/view")
    Call<GetData> doGetListResources();

    @POST("/signup")
    Call<Void> executeSignup (@Body HashMap<String, String> map);





}
