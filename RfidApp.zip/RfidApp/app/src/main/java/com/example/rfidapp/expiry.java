package com.example.rfidapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;

public class expiry extends Fragment {

    public expiry()
    {

    }
    public static expiry newInstance() {
        return new expiry();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
