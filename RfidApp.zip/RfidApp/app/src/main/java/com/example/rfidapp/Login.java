package com.example.rfidapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.rfidapp.Retrofit.RetrofitInterface;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Login extends AppCompatActivity {
    private Retrofit retrofit;
    private String name="",pass2="", email="",email1="",pass="";
    private RetrofitInterface retrofitInterface;
    private String BASE_URL = "http://192.168.0.102:3000";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .build();
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        final  EditText emailEdit = findViewById(R.id.emailEdit);
      final  EditText passwordEdit =findViewById(R.id.passwordEdit);
      final  TextView signuptv = findViewById(R.id.signuptv);
        retrofitInterface = retrofit.create(RetrofitInterface.class);

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HashMap<String, String> map = new HashMap<>();

                map.put("email", emailEdit.getText().toString());
                map.put("password", passwordEdit.getText().toString());
                email1 = emailEdit.getText().toString();
                System.out.println("fffffffffff"+ email1);
                pass2 = passwordEdit.getText().toString();
                System.out.println("fffffffffff"+ pass2);
                Call<LoginResult> call = retrofitInterface.executeLogin(map);

                call.enqueue(new Callback<LoginResult>() {
                    @Override
                    public void onResponse(Call<LoginResult> call, Response<LoginResult> response) {

                        if (response.code() == 200) {

                            LoginResult result = response.body();
                            pass = result.getName();
                            System.out.println("fffffffffff"+ pass);
                            email = result.getEmail();
                            System.out.println("fffffffffff"+ email);

                            if(email.equals(email1)  )
                            {
                                startActivity(new Intent(Login.this,MainActivity.class));
                            }

                        } else if (response.code() == 404) {
                            if(email1.equals("") || pass2.equals("")) {
                                Toast.makeText(Login.this, "Please enter valid credentials", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(Login.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                    @Override
                    public void onFailure(Call<LoginResult> call, Throwable t) {
                        Toast.makeText(Login.this, t.getMessage(),
                                Toast.LENGTH_SHORT).show();
                        System.out.println("eeeeeeeeeeeeeeeeeeeeeeeeee" + t.getMessage() );
                    }
                });
            }
        });


        signuptv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this, Register.class));
            }
        });
    }

}
